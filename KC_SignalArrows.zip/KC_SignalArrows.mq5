//+------------------------------------------------------------------+
//|  KC_SignalArrows.mq5                                             |
//|  Keltner Channel breakout arrows — strict Buy/Sell alternation:  |
//|    BUY  — first bar to close ABOVE the upper KC band             |
//|    SELL — first bar to close BELOW the lower KC band             |
//|  Signals follow a strict sequence: Buy, Sell, Buy, Sell.         |
//|  Designed to run alongside KC_ColouredCandles without conflict.  |
//+------------------------------------------------------------------+
#property copyright "Trade-a-Day"
#property version   "1.00"
#property indicator_chart_window
#property indicator_buffers 2
#property indicator_plots   2

//---- Plot 0: Buy arrows
#property indicator_type1   DRAW_ARROW
#property indicator_color1  clrLimeGreen
#property indicator_width1  4
#property indicator_label1  "KC Buy"

//---- Plot 1: Sell arrows
#property indicator_type2   DRAW_ARROW
#property indicator_color2  clrCrimson
#property indicator_width2  4
#property indicator_label2  "KC Sell"

//---- Inputs
input int    EMA_Period      = 20;             // EMA period (middle line)
input int    ATR_Period      = 20;             // ATR period
input double ATR_Multiplier  = 1.0;            // ATR multiplier
input int    BuyArrowCode    = 225;            // Arrow code — Buy
input int    SellArrowCode   = 226;            // Arrow code — Sell
input int    ArrowDistance   = 4;              // Arrow offset from candle (points)
input int    ArrowSize       = 4;              // Arrow size
input color  BuyArrowColor   = clrLimeGreen;   // Buy arrow colour
input color  SellArrowColor  = clrCrimson;     // Sell arrow colour
input bool   SoundAlert      = true;           // Enable sound alert
input string BuySoundFile    = "alert.wav";    // Buy sound file
input string SellSoundFile   = "alert2.wav";   // Sell sound file
input bool   PopupAlert      = false;          // Enable popup alert

//---- Buffers
double BuyBuffer[];
double SellBuffer[];

//---- Indicator handles
int g_emaHandle = INVALID_HANDLE;
int g_atrHandle = INVALID_HANDLE;

//---- State
datetime g_lastAlertBar = 0;

//+------------------------------------------------------------------+
int OnInit()
{
   SetIndexBuffer(0, BuyBuffer,  INDICATOR_DATA);
   SetIndexBuffer(1, SellBuffer, INDICATOR_DATA);

   PlotIndexSetInteger(0, PLOT_ARROW,      BuyArrowCode);
   PlotIndexSetInteger(1, PLOT_ARROW,      SellArrowCode);
   PlotIndexSetInteger(0, PLOT_LINE_COLOR, 0, BuyArrowColor);
   PlotIndexSetInteger(1, PLOT_LINE_COLOR, 0, SellArrowColor);
   PlotIndexSetInteger(0, PLOT_LINE_WIDTH, ArrowSize);
   PlotIndexSetInteger(1, PLOT_LINE_WIDTH, ArrowSize);

   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);

   g_emaHandle = iEMA(_Symbol, PERIOD_CURRENT, EMA_Period, 0, PRICE_CLOSE);
   g_atrHandle = iATR(_Symbol, PERIOD_CURRENT, ATR_Period);

   if(g_emaHandle == INVALID_HANDLE || g_atrHandle == INVALID_HANDLE)
   {
      Print("KC_SignalArrows: Failed to create indicator handles.");
      return(INIT_FAILED);
   }

   IndicatorSetString(INDICATOR_SHORTNAME,
      "KC Signal Arrows (" + IntegerToString(EMA_Period) +
      "," + IntegerToString(ATR_Period) +
      "," + DoubleToString(ATR_Multiplier, 1) + ")");

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   if(g_emaHandle != INVALID_HANDLE) IndicatorRelease(g_emaHandle);
   if(g_atrHandle != INVALID_HANDLE) IndicatorRelease(g_atrHandle);
}

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double   &open[],
                const double   &high[],
                const double   &low[],
                const double   &close[],
                const long     &tick_volume[],
                const long     &volume[],
                const int      &spread[])
{
   int minBars = MathMax(EMA_Period, ATR_Period) + 1;
   if(rates_total < minBars) return 0;

   //---- Copy EMA and ATR into chronological arrays
   double emaLocal[];
   double atrLocal[];
   ArraySetAsSeries(emaLocal, false);
   ArraySetAsSeries(atrLocal, false);
   ArrayResize(emaLocal, rates_total);
   ArrayResize(atrLocal, rates_total);

   if(CopyBuffer(g_emaHandle, 0, 0, rates_total, emaLocal) <= 0) return 0;
   if(CopyBuffer(g_atrHandle, 0, 0, rates_total, atrLocal) <= 0) return 0;

   //---- Copy price data into chronological arrays
   double c[], h[], l[];
   ArraySetAsSeries(c, false);
   ArraySetAsSeries(h, false);
   ArraySetAsSeries(l, false);
   ArrayResize(c, rates_total);
   ArrayResize(h, rates_total);
   ArrayResize(l, rates_total);

   if(CopyClose(_Symbol, PERIOD_CURRENT, 0, rates_total, c) <= 0) return 0;
   if(CopyHigh (_Symbol, PERIOD_CURRENT, 0, rates_total, h) <= 0) return 0;
   if(CopyLow  (_Symbol, PERIOD_CURRENT, 0, rates_total, l) <= 0) return 0;

   //---- Point size for arrow offset
   double pointSize = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   double offset    = ArrowDistance * pointSize;

   //==================================================================
   // Always replay full history so lastSig is correct for alternation
   //==================================================================
   int lastSig = 0;   // 0=none, 1=buy, -1=sell

   //---- Pass 1: replay confirmed history to establish lastSig
   int replayEnd = (prev_calculated > 1) ? prev_calculated - 1 : rates_total;

   for(int i = minBars; i < replayEnd; i++)
   {
      BuyBuffer[i]  = EMPTY_VALUE;
      SellBuffer[i] = EMPTY_VALUE;

      double upper = emaLocal[i] + ATR_Multiplier * atrLocal[i];
      double lower = emaLocal[i] - ATR_Multiplier * atrLocal[i];

      bool rawBuy  = (c[i] > upper);
      bool rawSell = (c[i] < lower);

      if(rawBuy && lastSig != 1)
      {
         BuyBuffer[i] = l[i] - offset;
         lastSig = 1;
      }
      else if(rawSell && lastSig != -1)
      {
         SellBuffer[i] = h[i] + offset;
         lastSig = -1;
      }
   }

   //---- Pass 2: live bars (from prev_calculated - 1 onward)
   int liveStart = (prev_calculated > 1) ? prev_calculated - 1 : replayEnd;

   for(int i = liveStart; i < rates_total; i++)
   {
      BuyBuffer[i]  = EMPTY_VALUE;
      SellBuffer[i] = EMPTY_VALUE;

      double upper = emaLocal[i] + ATR_Multiplier * atrLocal[i];
      double lower = emaLocal[i] - ATR_Multiplier * atrLocal[i];

      bool rawBuy  = (c[i] > upper);
      bool rawSell = (c[i] < lower);

      if(rawBuy && lastSig != 1)
      {
         BuyBuffer[i] = l[i] - offset;
         lastSig = 1;

         if(i == rates_total - 1 && time[i] != g_lastAlertBar)
         {
            g_lastAlertBar = time[i];
            if(SoundAlert) PlaySound(BuySoundFile);
            if(PopupAlert) Alert("KC Signal BUY — ", _Symbol,
                                 " Close=", DoubleToString(c[i], _Digits));
         }
      }
      else if(rawSell && lastSig != -1)
      {
         SellBuffer[i] = h[i] + offset;
         lastSig = -1;

         if(i == rates_total - 1 && time[i] != g_lastAlertBar)
         {
            g_lastAlertBar = time[i];
            if(SoundAlert) PlaySound(SellSoundFile);
            if(PopupAlert) Alert("KC Signal SELL — ", _Symbol,
                                 " Close=", DoubleToString(c[i], _Digits));
         }
      }
   }

   return(rates_total);
}
//+------------------------------------------------------------------+
