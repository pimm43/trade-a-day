//+------------------------------------------------------------------+
//|                                         EMA_Detach_Panel.mq5    |
//|                                                                  |
//|  Manual / Auto trading panel driven by EMA Detach signals.       |
//|                                                                  |
//|  MANUAL mode — discretionary entry via BUY / SELL buttons;       |
//|               the panel highlights the live EMA Detach signal    |
//|               for guidance but does not execute automatically.   |
//|                                                                  |
//|  AUTO mode   — a trade fires automatically on every new EMA      |
//|               Detach signal (strict Buy → Sell alternation).     |
//|               Any existing position is closed before the new     |
//|               one is opened.                                     |
//|                                                                  |
//|  Both modes share:                                               |
//|    · ATR-based initial stop loss                                 |
//|    · ATR trailing stop updated on every tick                     |
//|    · Break Even button (moves SL to open price)                  |
//|    · Close All button                                            |
//|    · Draggable panel                                             |
//|                                                                  |
//|  Signal logic (mirrors EMA_Detach_Signals v1.01):               |
//|    BUY  — last closed bar fully above shifted EMA                |
//|           AND previous bar was NOT fully above                   |
//|           AND last signal was a Sell (strict alternation)        |
//|    SELL — last closed bar fully below shifted EMA                |
//|           AND previous bar was NOT fully below                   |
//|           AND last signal was a Buy                              |
//+------------------------------------------------------------------+
#property copyright   "Trade-a-Day"
#property version     "1.00"
#property description "EMA Detach Manual / Auto Trading Panel"

#include <Trade\Trade.mqh>

//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
input group "=== EMA Settings ==="
input int                EMA_Period  = 8;
input int                EMA_Shift   = 1;
input ENUM_APPLIED_PRICE EMA_Price   = PRICE_CLOSE;

input group "=== Trade Settings ==="
input double  LotSize          = 1.0;
input int     ATR_Period        = 20;
input double  ATR_SL_Mult       = 2.0;
input double  ATR_Trail_Mult    = 2.0;
input int     BreakEvenPoints   = 7;
input long    MagicNumber       = 800002;

input group "=== Panel ==="
input int     PanelX = 20;
input int     PanelY = 30;

//+------------------------------------------------------------------+
//| Panel geometry                                                   |
//+------------------------------------------------------------------+
#define PANEL_W  212
#define PANEL_H  257
#define TITLE_H   26
#define BTN_W    192
#define BTN_H     30
#define BTN_X     10
#define GAP        5

//+------------------------------------------------------------------+
//| Object name constants  (prefix EDP_ avoids collisions)          |
//+------------------------------------------------------------------+
#define PFX       "EDP_"
#define OBJ_BG      PFX "BG"
#define OBJ_TBAR    PFX "TitleBar"
#define OBJ_TITLE   PFX "Title"
#define OBJ_MODE    PFX "Mode"
#define OBJ_SIGNAL  PFX "Signal"
#define OBJ_BUY     PFX "Buy"
#define OBJ_SELL    PFX "Sell"
#define OBJ_BE      PFX "BE"
#define OBJ_CLOSE   PFX "CloseAll"
#define OBJ_STATUS  PFX "Status"

//+------------------------------------------------------------------+
//| Global state                                                     |
//+------------------------------------------------------------------+
CTrade   g_trade;
int      g_maHandle  = INVALID_HANDLE;
int      g_atrHandle = INVALID_HANDLE;

//--- Panel position (top-left corner of the background rectangle)
int      g_panelX, g_panelY;

//--- Drag state
bool     g_dragging  = false;
int      g_dragOffX, g_dragOffY;

//--- Signal tracking
bool     g_autoMode    = false;  // false = MANUAL, true = AUTO
int      g_lastSig     = 0;      // 0=none, 1=buy last, -1=sell last
bool     g_initialized = false;
datetime g_lastSigBar  = 0;      // time of bar on which the last signal fired

//+------------------------------------------------------------------+
//| OnInit                                                           |
//+------------------------------------------------------------------+
int OnInit()
{
   g_panelX = PanelX;
   g_panelY = PanelY;

   g_maHandle  = iMA (_Symbol, _Period, EMA_Period, EMA_Shift, MODE_EMA, EMA_Price);
   g_atrHandle = iATR(_Symbol, _Period, ATR_Period);
   if(g_maHandle == INVALID_HANDLE || g_atrHandle == INVALID_HANDLE)
   {
      Alert("EMA Detach Panel: Failed to create indicator handles.");
      return INIT_FAILED;
   }

   g_trade.SetMagicNumber((ulong)MagicNumber);
   g_trade.SetDeviationInPoints(10);

   //--- Enable mouse-move events for drag support
   ChartSetInteger(0, CHART_EVENT_MOUSE_MOVE, true);

   BuildPanel();
   UpdateDisplay();
   ChartRedraw();
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| OnDeinit                                                         |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   if(g_maHandle  != INVALID_HANDLE) IndicatorRelease(g_maHandle);
   if(g_atrHandle != INVALID_HANDLE) IndicatorRelease(g_atrHandle);
   ObjectsDeleteAll(0, PFX);
   ChartSetInteger(0, CHART_MOUSE_SCROLL, true);
   ChartRedraw();
}

//+------------------------------------------------------------------+
//| OnTick                                                           |
//+------------------------------------------------------------------+
void OnTick()
{
   //--- Build lastSig from full history on the very first tick
   if(!g_initialized)
   {
      InitLastSig();
      g_initialized = true;
   }

   CheckSignalAndTrade();
   TrailStop();
   UpdateDisplay();
}

//+------------------------------------------------------------------+
//| Replay all confirmed history bars to set g_lastSig correctly     |
//+------------------------------------------------------------------+
void InitLastSig()
{
   int rates   = Bars(_Symbol, _Period);
   int minBars = EMA_Period + EMA_Shift + 2;
   if(rates < minBars) return;

   double ema[], cl[], hi[], lo[];
   ArraySetAsSeries(ema, false);
   ArraySetAsSeries(cl,  false);
   ArraySetAsSeries(hi,  false);
   ArraySetAsSeries(lo,  false);

   if(CopyBuffer(g_maHandle,               0, 0, rates, ema) <= 0) return;
   if(CopyClose(_Symbol, _Period,           0, rates, cl)    <= 0) return;
   if(CopyHigh (_Symbol, _Period,           0, rates, hi)    <= 0) return;
   if(CopyLow  (_Symbol, _Period,           0, rates, lo)    <= 0) return;

   int firstBar = EMA_Period + EMA_Shift + 1;

   //--- Replay up to but NOT including the current live bar (index rates-1)
   //--- The last closed bar (rates-2) is left for CheckSignalAndTrade
   for(int i = firstBar; i < rates - 1; i++)
   {
      if(ema[i] <= 0.0 || ema[i - 1] <= 0.0) continue;

      bool aboveNow  = (cl[i]     > ema[i]     && lo[i]     > ema[i]);
      bool abovePrev = (cl[i - 1] > ema[i - 1] && lo[i - 1] > ema[i - 1]);
      bool belowNow  = (cl[i]     < ema[i]     && hi[i]     < ema[i]);
      bool belowPrev = (cl[i - 1] < ema[i - 1] && hi[i - 1] < ema[i - 1]);

      if(aboveNow && !abovePrev && g_lastSig != 1)
         g_lastSig = 1;
      else if(belowNow && !belowPrev && g_lastSig != -1)
         g_lastSig = -1;
   }
}

//+------------------------------------------------------------------+
//| Check last closed bar for a new EMA Detach signal                |
//+------------------------------------------------------------------+
void CheckSignalAndTrade()
{
   //--- Copy 3 bars: [0]=2 bars ago, [1]=last closed, [2]=live (chronological)
   double   ema[3], cl[3], hi[3], lo[3];
   datetime t[3];
   ArraySetAsSeries(ema, false);
   ArraySetAsSeries(cl,  false);
   ArraySetAsSeries(hi,  false);
   ArraySetAsSeries(lo,  false);
   ArraySetAsSeries(t,   false);

   if(CopyBuffer(g_maHandle,              0, 0, 3, ema) != 3) return;
   if(CopyClose(_Symbol, _Period,            0, 3, cl)  != 3) return;
   if(CopyHigh (_Symbol, _Period,            0, 3, hi)  != 3) return;
   if(CopyLow  (_Symbol, _Period,            0, 3, lo)  != 3) return;
   if(CopyTime (_Symbol, _Period,            0, 3, t)   != 3) return;

   if(ema[1] <= 0.0 || ema[0] <= 0.0) return;

   //--- Signal conditions on last closed bar (index 1) vs the bar before (index 0)
   bool aboveNow  = (cl[1] > ema[1] && lo[1] > ema[1]);
   bool abovePrev = (cl[0] > ema[0] && lo[0] > ema[0]);
   bool belowNow  = (cl[1] < ema[1] && hi[1] < ema[1]);
   bool belowPrev = (cl[0] < ema[0] && hi[0] < ema[0]);

   datetime barTime = t[1];

   if(aboveNow && !abovePrev && g_lastSig != 1 && barTime != g_lastSigBar)
   {
      g_lastSig    = 1;
      g_lastSigBar = barTime;
      if(g_autoMode) ExecuteTrade(ORDER_TYPE_BUY);
   }
   else if(belowNow && !belowPrev && g_lastSig != -1 && barTime != g_lastSigBar)
   {
      g_lastSig    = -1;
      g_lastSigBar = barTime;
      if(g_autoMode) ExecuteTrade(ORDER_TYPE_SELL);
   }
}

//+------------------------------------------------------------------+
//| Open a trade with ATR-based initial stop loss                    |
//+------------------------------------------------------------------+
void ExecuteTrade(ENUM_ORDER_TYPE type)
{
   CloseAll();   // one position at a time

   double atrBuf[1];
   if(CopyBuffer(g_atrHandle, 0, 1, 1, atrBuf) != 1) return;
   double atr = atrBuf[0];

   if(type == ORDER_TYPE_BUY)
   {
      double price = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double sl    = price - ATR_SL_Mult * atr;
      g_trade.Buy(LotSize, _Symbol, price, sl, 0.0);
   }
   else
   {
      double price = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      double sl    = price + ATR_SL_Mult * atr;
      g_trade.Sell(LotSize, _Symbol, price, sl, 0.0);
   }
}

//+------------------------------------------------------------------+
//| Trailing stop — only ever moves the stop in the trade's favour   |
//+------------------------------------------------------------------+
void TrailStop()
{
   double atrBuf[1];
   if(CopyBuffer(g_atrHandle, 0, 1, 1, atrBuf) != 1) return;
   double trail = ATR_Trail_Mult * atrBuf[0];
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   double bid   = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double ask   = SymbolInfoDouble(_Symbol, SYMBOL_ASK);

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(!PositionSelectByTicket(ticket))                           continue;
      if(PositionGetInteger(POSITION_MAGIC)  != (long)MagicNumber) continue;
      if(PositionGetString (POSITION_SYMBOL) != _Symbol)           continue;

      double sl   = PositionGetDouble(POSITION_SL);
      double tp   = PositionGetDouble(POSITION_TP);
      ENUM_POSITION_TYPE pt =
         (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);

      if(pt == POSITION_TYPE_BUY)
      {
         double newSL = bid - trail;
         if(newSL > sl + point) g_trade.PositionModify(ticket, newSL, tp);
      }
      else
      {
         double newSL = ask + trail;
         if(sl == 0.0 || newSL < sl - point)
            g_trade.PositionModify(ticket, newSL, tp);
      }
   }
}

//+------------------------------------------------------------------+
//| Move stop to open price if profit >= BreakEvenPoints             |
//+------------------------------------------------------------------+
void SetBreakEven()
{
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   double bid   = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double ask   = SymbolInfoDouble(_Symbol, SYMBOL_ASK);

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(!PositionSelectByTicket(ticket))                           continue;
      if(PositionGetInteger(POSITION_MAGIC)  != (long)MagicNumber) continue;
      if(PositionGetString (POSITION_SYMBOL) != _Symbol)           continue;

      double open = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl   = PositionGetDouble(POSITION_SL);
      double tp   = PositionGetDouble(POSITION_TP);
      ENUM_POSITION_TYPE pt =
         (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);

      if(pt == POSITION_TYPE_BUY)
      {
         double profitPts = (bid - open) / point;
         if(profitPts >= BreakEvenPoints && sl < open)
            g_trade.PositionModify(ticket, open, tp);
      }
      else
      {
         double profitPts = (open - ask) / point;
         if(profitPts >= BreakEvenPoints && (sl > open || sl == 0.0))
            g_trade.PositionModify(ticket, open, tp);
      }
   }
}

//+------------------------------------------------------------------+
//| Close all EA positions on this symbol                            |
//+------------------------------------------------------------------+
void CloseAll()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(!PositionSelectByTicket(ticket))                           continue;
      if(PositionGetInteger(POSITION_MAGIC)  != (long)MagicNumber) continue;
      if(PositionGetString (POSITION_SYMBOL) != _Symbol)           continue;
      g_trade.PositionClose(ticket);
   }
}

//+------------------------------------------------------------------+
//| Create panel objects                                             |
//+------------------------------------------------------------------+
void BuildPanel()
{
   int x = g_panelX, y = g_panelY;

   //--- Background
   MakeRect(OBJ_BG,   x, y, PANEL_W, PANEL_H, C'18,18,38');

   //--- Title bar (darker band at top)
   MakeRect(OBJ_TBAR, x, y, PANEL_W, TITLE_H,  C'30,50,90');
   MakeLabel(OBJ_TITLE, x + 9, y + 6,
             "EMA Detach Panel", clrWhite, 10, true);

   int yc = y + TITLE_H + GAP;

   //--- Mode toggle button
   MakeButton(OBJ_MODE, x + BTN_X, yc, BTN_W, BTN_H,
              "◉  MANUAL MODE", C'65,65,105');
   yc += BTN_H + GAP;

   //--- Signal status label
   MakeLabel(OBJ_SIGNAL, x + BTN_X, yc + 4,
             "Signal: —", clrSilver, 9, false);
   yc += 22 + GAP;

   //--- BUY button
   MakeButton(OBJ_BUY,  x + BTN_X, yc, BTN_W, BTN_H,
              "BUY  ▲", C'34,120,34');
   yc += BTN_H + GAP;

   //--- SELL button
   MakeButton(OBJ_SELL, x + BTN_X, yc, BTN_W, BTN_H,
              "SELL  ▼", C'160,30,30');
   yc += BTN_H + GAP;

   //--- Break Even button
   MakeButton(OBJ_BE,   x + BTN_X, yc, BTN_W, BTN_H,
              "Break Even", C'160,100,30');
   yc += BTN_H + GAP;

   //--- Close All button
   MakeButton(OBJ_CLOSE, x + BTN_X, yc, BTN_W, BTN_H,
              "Close All", C'60,70,85');
   yc += BTN_H + GAP;

   //--- Status label
   MakeLabel(OBJ_STATUS, x + BTN_X, yc + 3,
             "No position", clrSilver, 8, false);
}

//--- Helpers ---------------------------------------------------------
void MakeRect(string name, int x, int y, int w, int h, color bg)
{
   ObjectCreate(0, name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_CORNER,      CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE,   x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE,   y);
   ObjectSetInteger(0, name, OBJPROP_XSIZE,       w);
   ObjectSetInteger(0, name, OBJPROP_YSIZE,       h);
   ObjectSetInteger(0, name, OBJPROP_BGCOLOR,     bg);
   ObjectSetInteger(0, name, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, name, OBJPROP_COLOR,       bg);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE,  false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN,      true);
   ObjectSetInteger(0, name, OBJPROP_BACK,        false);
}

void MakeButton(string name, int x, int y, int w, int h,
                string txt, color bg)
{
   ObjectCreate(0, name, OBJ_BUTTON, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_CORNER,    CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_XSIZE,     w);
   ObjectSetInteger(0, name, OBJPROP_YSIZE,     h);
   ObjectSetString (0, name, OBJPROP_TEXT,      txt);
   ObjectSetInteger(0, name, OBJPROP_BGCOLOR,   bg);
   ObjectSetInteger(0, name, OBJPROP_COLOR,     clrWhite);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE,  9);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN,    true);
}

void MakeLabel(string name, int x, int y, string txt,
               color clr, int fs, bool bold)
{
   ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_CORNER,    CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetString (0, name, OBJPROP_TEXT,      txt);
   ObjectSetInteger(0, name, OBJPROP_COLOR,     clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE,  fs);
   if(bold) ObjectSetString(0, name, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN,    true);
}

//+------------------------------------------------------------------+
//| Shift every panel object by (dx, dy) pixels                     |
//+------------------------------------------------------------------+
void MovePanel(int dx, int dy)
{
   if(dx == 0 && dy == 0) return;
   g_panelX += dx;
   g_panelY += dy;

   string objs[] = {OBJ_BG, OBJ_TBAR, OBJ_TITLE, OBJ_MODE, OBJ_SIGNAL,
                    OBJ_BUY, OBJ_SELL, OBJ_BE, OBJ_CLOSE, OBJ_STATUS};
   int n = ArraySize(objs);
   for(int i = 0; i < n; i++)
   {
      int ox = (int)ObjectGetInteger(0, objs[i], OBJPROP_XDISTANCE);
      int oy = (int)ObjectGetInteger(0, objs[i], OBJPROP_YDISTANCE);
      ObjectSetInteger(0, objs[i], OBJPROP_XDISTANCE, ox + dx);
      ObjectSetInteger(0, objs[i], OBJPROP_YDISTANCE, oy + dy);
   }
}

//+------------------------------------------------------------------+
//| Refresh all dynamic panel text and colours                       |
//+------------------------------------------------------------------+
void UpdateDisplay()
{
   //--- Mode button
   string modeText = g_autoMode ? "◉  AUTO MODE" : "◉  MANUAL MODE";
   color  modeBg   = g_autoMode ? C'20,95,55'   : C'65,65,105';
   ObjectSetString (0, OBJ_MODE, OBJPROP_TEXT,   modeText);
   ObjectSetInteger(0, OBJ_MODE, OBJPROP_BGCOLOR, modeBg);

   //--- Signal label
   string sigText;  color sigClr;
   if(g_lastSig ==  1) { sigText = "Signal: ▲ BUY";  sigClr = clrLimeGreen; }
   else if(g_lastSig == -1) { sigText = "Signal: ▼ SELL"; sigClr = clrCrimson;   }
   else                { sigText = "Signal: —";        sigClr = clrSilver;    }
   ObjectSetString (0, OBJ_SIGNAL, OBJPROP_TEXT,  sigText);
   ObjectSetInteger(0, OBJ_SIGNAL, OBJPROP_COLOR, sigClr);

   //--- BUY / SELL buttons — dimmed when in AUTO mode
   ObjectSetInteger(0, OBJ_BUY,  OBJPROP_BGCOLOR,
                    g_autoMode ? C'22,55,22'  : C'34,120,34');
   ObjectSetInteger(0, OBJ_SELL, OBJPROP_BGCOLOR,
                    g_autoMode ? C'65,20,20'  : C'160,30,30');

   //--- Position status
   string statusText = "No position";
   color  statusClr  = clrSilver;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(!PositionSelectByTicket(ticket))                           continue;
      if(PositionGetInteger(POSITION_MAGIC)  != (long)MagicNumber) continue;
      if(PositionGetString (POSITION_SYMBOL) != _Symbol)           continue;

      ENUM_POSITION_TYPE pt =
         (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double open   = PositionGetDouble(POSITION_PRICE_OPEN);
      double profit = PositionGetDouble(POSITION_PROFIT);
      double bid    = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      double ask    = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double point  = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
      string dir    = (pt == POSITION_TYPE_BUY) ? "▲ Buy" : "▼ Sell";
      double pnlPts = (pt == POSITION_TYPE_BUY)
                         ? (bid - open) / point
                         : (open - ask) / point;

      statusText = StringFormat("%s %.2f @ %.5f | %+.1f pts / %+.1f pips",
                                dir, LotSize, open, pnlPts, pnlPts / 10.0);
      statusClr  = (profit >= 0.0) ? clrLimeGreen : clrCrimson;
      break;
   }
   ObjectSetString (0, OBJ_STATUS, OBJPROP_TEXT,  statusText);
   ObjectSetInteger(0, OBJ_STATUS, OBJPROP_COLOR, statusClr);

   ChartRedraw();
}

//+------------------------------------------------------------------+
//| Button clicks and panel drag                                     |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,
                  const long   &lparam,
                  const double &dparam,
                  const string &sparam)
{
   //----------------------------------------------------------------
   // Button clicks
   //----------------------------------------------------------------
   if(id == CHARTEVENT_OBJECT_CLICK)
   {
      if(sparam == OBJ_MODE)
      {
         g_autoMode = !g_autoMode;
         ObjectSetInteger(0, OBJ_MODE, OBJPROP_STATE, false);
         UpdateDisplay();
      }
      else if(sparam == OBJ_BUY && !g_autoMode)
      {
         ObjectSetInteger(0, OBJ_BUY,  OBJPROP_STATE, false);
         ExecuteTrade(ORDER_TYPE_BUY);
      }
      else if(sparam == OBJ_SELL && !g_autoMode)
      {
         ObjectSetInteger(0, OBJ_SELL, OBJPROP_STATE, false);
         ExecuteTrade(ORDER_TYPE_SELL);
      }
      else if(sparam == OBJ_BE)
      {
         ObjectSetInteger(0, OBJ_BE,   OBJPROP_STATE, false);
         SetBreakEven();
      }
      else if(sparam == OBJ_CLOSE)
      {
         ObjectSetInteger(0, OBJ_CLOSE, OBJPROP_STATE, false);
         CloseAll();
      }
   }

   //----------------------------------------------------------------
   // Panel drag via title bar
   //----------------------------------------------------------------
   if(id == CHARTEVENT_MOUSE_MOVE)
   {
      int  mx = (int)lparam;
      int  my = (int)dparam;
      bool lb = (((int)sparam) & 1) != 0;

      //--- Release
      if(!lb && g_dragging)
      {
         g_dragging = false;
         ChartSetInteger(0, CHART_MOUSE_SCROLL, true);
      }

      //--- Start drag if mouse presses down on the title bar
      if(lb && !g_dragging)
      {
         if(mx >= g_panelX            && mx <= g_panelX + PANEL_W &&
            my >= g_panelY            && my <= g_panelY + TITLE_H)
         {
            g_dragging = true;
            g_dragOffX = mx - g_panelX;
            g_dragOffY = my - g_panelY;
            ChartSetInteger(0, CHART_MOUSE_SCROLL, false);
         }
      }

      //--- Move
      if(lb && g_dragging)
      {
         int dx = (mx - g_dragOffX) - g_panelX;
         int dy = (my - g_dragOffY) - g_panelY;
         MovePanel(dx, dy);
      }
   }
}
//+------------------------------------------------------------------+
