//+------------------------------------------------------------------+
//|  SH_SL_Lines.mq5                                                 |
//|  Swing High / Swing Low horizontal lines with ON/OFF button:     |
//|    - Draws a horizontal line at the most recent confirmed swing   |
//|      high and the most recent confirmed swing low                 |
//|    - Each line extends LineExtendBars bars to the right           |
//|    - Top-left button toggles all lines ON (teal) / OFF (grey)    |
//+------------------------------------------------------------------+
#property copyright "Trade-a-Day"
#property version   "1.00"
#property indicator_chart_window
#property indicator_buffers 0
#property indicator_plots   0

//---- Object names
#define OBJ_LINE_HIGH  "SHL_High"
#define OBJ_LINE_LOW   "SHL_Low"
#define OBJ_BUTTON     "SHL_Btn"

//---- Inputs
input int              LookbackBars    = 8;              // Bars either side to confirm swing
input int              LineExtendBars  = 4;              // Bars to extend line to the right
input color            SwingHighColor  = clrCrimson;     // Swing high line colour
input color            SwingLowColor   = clrDodgerBlue;  // Swing low line colour
input int              LineWidth        = 2;             // Line width
input ENUM_LINE_STYLE  LineStyle        = STYLE_SOLID;   // Line style

//---- State
bool g_linesOn = true;   // Lines currently visible

//+------------------------------------------------------------------+
int OnInit()
{
   //---- Create the ON/OFF toggle button
   if(ObjectFind(0, OBJ_BUTTON) < 0)
      ObjectCreate(0, OBJ_BUTTON, OBJ_BUTTON, 0, 0, 0);
   ObjectSetInteger(0, OBJ_BUTTON, OBJPROP_CORNER,    CORNER_LEFT_UPPER);
   ObjectSetInteger(0, OBJ_BUTTON, OBJPROP_XDISTANCE, 10);
   ObjectSetInteger(0, OBJ_BUTTON, OBJPROP_YDISTANCE, 10);
   ObjectSetInteger(0, OBJ_BUTTON, OBJPROP_XSIZE,     50);
   ObjectSetInteger(0, OBJ_BUTTON, OBJPROP_YSIZE,     22);
   ObjectSetInteger(0, OBJ_BUTTON, OBJPROP_FONTSIZE,  9);
   ObjectSetInteger(0, OBJ_BUTTON, OBJPROP_COLOR,     clrWhite);
   SetButtonState(true);

   IndicatorSetString(INDICATOR_SHORTNAME,
      "SH/SL Lines (" + IntegerToString(LookbackBars) + ")");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   ObjectDelete(0, OBJ_LINE_HIGH);
   ObjectDelete(0, OBJ_LINE_LOW);
   ObjectDelete(0, OBJ_BUTTON);
}

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double   &open[],
                const double   &high[],
                const double   &low[],
                const double   &close[],
                const long     &tick_volume[],
                const long     &volume[],
                const int      &spread[])
{
   int minBars = LookbackBars * 2 + 2;
   if(rates_total < minBars) return 0;

   if(g_linesOn)
      DrawSwingLines(rates_total);

   return(rates_total);
}

//+------------------------------------------------------------------+
void OnChartEvent(const int     id,
                  const long   &lparam,
                  const double &dparam,
                  const string &sparam)
{
   if(id == CHARTEVENT_OBJECT_CLICK && sparam == OBJ_BUTTON)
   {
      g_linesOn = !g_linesOn;
      SetButtonState(g_linesOn);

      if(g_linesOn)
      {
         //---- Redraw lines immediately using current data
         int total = Bars(_Symbol, PERIOD_CURRENT);
         if(total > LookbackBars * 2 + 2)
            DrawSwingLines(total);
      }
      else
      {
         ObjectDelete(0, OBJ_LINE_HIGH);
         ObjectDelete(0, OBJ_LINE_LOW);
      }

      //---- Release the button (un-press it visually)
      ObjectSetInteger(0, OBJ_BUTTON, OBJPROP_STATE, false);
      ChartRedraw(0);
   }
}

//+------------------------------------------------------------------+
//| Update button appearance based on current ON/OFF state           |
//+------------------------------------------------------------------+
void SetButtonState(bool on)
{
   if(on)
   {
      ObjectSetString (0, OBJ_BUTTON, OBJPROP_TEXT,    "ON");
      ObjectSetInteger(0, OBJ_BUTTON, OBJPROP_BGCOLOR, clrTeal);
   }
   else
   {
      ObjectSetString (0, OBJ_BUTTON, OBJPROP_TEXT,    "OFF");
      ObjectSetInteger(0, OBJ_BUTTON, OBJPROP_BGCOLOR, clrDimGray);
   }
}

//+------------------------------------------------------------------+
//| Scan for most recent swing high / low and draw horizontal lines  |
//+------------------------------------------------------------------+
void DrawSwingLines(int rates_total)
{
   //---- Copy high / low / time into chronological arrays
   double hiArr[];
   double loArr[];
   datetime tmArr[];
   ArraySetAsSeries(hiArr,  false);
   ArraySetAsSeries(loArr,  false);
   ArraySetAsSeries(tmArr,  false);
   ArrayResize(hiArr,  rates_total);
   ArrayResize(loArr,  rates_total);
   ArrayResize(tmArr,  rates_total);

   if(CopyHigh(_Symbol, PERIOD_CURRENT, 0, rates_total, hiArr) <= 0) return;
   if(CopyLow (_Symbol, PERIOD_CURRENT, 0, rates_total, loArr) <= 0) return;
   if(CopyTime(_Symbol, PERIOD_CURRENT, 0, rates_total, tmArr) <= 0) return;

   // Exclude the current live bar
   int lastConfirmed = rates_total - 2;

   int    swHiIdx = -1;  double swHiVal = 0;
   int    swLoIdx = -1;  double swLoVal = 0;

   for(int i = lastConfirmed; i >= LookbackBars; i--)
   {
      //---- Swing high
      if(swHiIdx < 0)
      {
         bool isHigh = true;
         for(int k = 1; k <= LookbackBars; k++)
         {
            if(hiArr[i - k] >= hiArr[i] || hiArr[i + k] >= hiArr[i])
            {
               isHigh = false;
               break;
            }
         }
         if(isHigh)
         {
            swHiIdx = i;
            swHiVal = hiArr[i];
         }
      }

      //---- Swing low
      if(swLoIdx < 0)
      {
         bool isLow = true;
         for(int k = 1; k <= LookbackBars; k++)
         {
            if(loArr[i - k] <= loArr[i] || loArr[i + k] <= loArr[i])
            {
               isLow = false;
               break;
            }
         }
         if(isLow)
         {
            swLoIdx = i;
            swLoVal = loArr[i];
         }
      }

      if(swHiIdx >= 0 && swLoIdx >= 0) break;
   }

   //---- Draw swing high line
   if(swHiIdx >= 0)
   {
      datetime t1 = tmArr[swHiIdx];
      // Extend right: clamp so we don't exceed array bounds
      int endIdx = MathMin(swHiIdx + LineExtendBars, rates_total - 1);
      datetime t2 = tmArr[endIdx];
      DrawHorizLine(OBJ_LINE_HIGH, t1, swHiVal, t2, swHiVal, SwingHighColor);
   }
   else
      ObjectDelete(0, OBJ_LINE_HIGH);

   //---- Draw swing low line
   if(swLoIdx >= 0)
   {
      datetime t1 = tmArr[swLoIdx];
      int endIdx = MathMin(swLoIdx + LineExtendBars, rates_total - 1);
      datetime t2 = tmArr[endIdx];
      DrawHorizLine(OBJ_LINE_LOW, t1, swLoVal, t2, swLoVal, SwingLowColor);
   }
   else
      ObjectDelete(0, OBJ_LINE_LOW);
}

//+------------------------------------------------------------------+
//| Create or move a two-point trend object used as a horiz line     |
//+------------------------------------------------------------------+
void DrawHorizLine(const string name,
                   datetime t1, double p1,
                   datetime t2, double p2,
                   color    lineColor)
{
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TREND, 0, t1, p1, t2, p2);
   else
   {
      ObjectSetInteger(0, name, OBJPROP_TIME,  0, t1);
      ObjectSetDouble (0, name, OBJPROP_PRICE, 0, p1);
      ObjectSetInteger(0, name, OBJPROP_TIME,  1, t2);
      ObjectSetDouble (0, name, OBJPROP_PRICE, 1, p2);
   }
   ObjectSetInteger(0, name, OBJPROP_COLOR,     lineColor);
   ObjectSetInteger(0, name, OBJPROP_WIDTH,     LineWidth);
   ObjectSetInteger(0, name, OBJPROP_STYLE,     LineStyle);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN,    true);
}
//+------------------------------------------------------------------+
