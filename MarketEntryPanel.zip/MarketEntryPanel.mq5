//+------------------------------------------------------------------+
//|  MarketEntryPanel.mq5                                            |
//|  Semi-automated trade management panel:                          |
//|    BUY / SELL buttons  — manual market entry                     |
//|    Break Even button   — moves SL to entry price                 |
//|    Close All button    — closes all positions on this symbol     |
//|  ATR-based initial stop loss + ATR trailing stop.                |
//|  Draggable panel with DimGray background.                        |
//+------------------------------------------------------------------+
#property copyright "Trade-a-Day"
#property version   "1.00"
#property strict

#include <Trade\Trade.mqh>

//---- Inputs
input double LotSize         = 1.0;     // Lot size
input int    ATR_Period      = 20;      // ATR period
input double ATR_SL_Mult    = 2.0;     // ATR multiplier — initial stop loss
input double ATR_Trail_Mult  = 2.0;    // ATR multiplier — trailing stop
input int    BreakEvenPoints = 7;      // Profit in points to enable break-even
input long   MagicNumber     = 800001; // Magic number

//---- Object prefix
#define PFX "MEP_"

//---- Object names
#define OBJ_BG       PFX"BG"
#define OBJ_TITLE    PFX"Title"
#define OBJ_BTN_BUY  PFX"BtnBuy"
#define OBJ_BTN_SELL PFX"BtnSell"
#define OBJ_BTN_BE   PFX"BtnBE"
#define OBJ_BTN_CA   PFX"BtnCA"
#define OBJ_STATUS   PFX"Status"

//---- Panel geometry
#define PANEL_W   200
#define PANEL_H   200
#define TITLE_H   24
#define BTN_H     30
#define BTN_W     180
#define BTN_X     10       // x offset inside panel
#define GAP       5
#define STATUS_H  40

//---- Panel position state
int g_panelX = 20;
int g_panelY = 30;

//---- Drag state
bool     g_dragging   = false;
int      g_dragOffX   = 0;
int      g_dragOffY   = 0;

//---- ATR handle
int g_atrHandle = INVALID_HANDLE;

//---- Trade object
CTrade g_trade;

//+------------------------------------------------------------------+
int OnInit()
{
   g_trade.SetExpertMagicNumber(MagicNumber);

   g_atrHandle = iATR(_Symbol, PERIOD_CURRENT, ATR_Period);
   if(g_atrHandle == INVALID_HANDLE)
   {
      Print("MarketEntryPanel: Failed to create ATR handle.");
      return(INIT_FAILED);
   }

   BuildPanel();
   UpdateStatus();
   ChartRedraw(0);
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   DeletePanel();
   ChartSetInteger(0, CHART_MOUSE_SCROLL, true);
   if(g_atrHandle != INVALID_HANDLE) IndicatorRelease(g_atrHandle);
}

//+------------------------------------------------------------------+
void OnTick()
{
   TrailStop();
   UpdateStatus();
}

//+------------------------------------------------------------------+
void OnChartEvent(const int     id,
                  const long   &lparam,
                  const double &dparam,
                  const string &sparam)
{
   //---- Button clicks
   if(id == CHARTEVENT_OBJECT_CLICK)
   {
      if(sparam == OBJ_BTN_BUY)  { ObjectSetInteger(0, sparam, OBJPROP_STATE, false); DoEntry(ORDER_TYPE_BUY);  return; }
      if(sparam == OBJ_BTN_SELL) { ObjectSetInteger(0, sparam, OBJPROP_STATE, false); DoEntry(ORDER_TYPE_SELL); return; }
      if(sparam == OBJ_BTN_BE)   { ObjectSetInteger(0, sparam, OBJPROP_STATE, false); DoBreakEven();            return; }
      if(sparam == OBJ_BTN_CA)   { ObjectSetInteger(0, sparam, OBJPROP_STATE, false); DoCloseAll();             return; }
   }

   //---- Mouse down on title bar — start drag
   if(id == CHARTEVENT_MOUSE_MOVE)
   {
      int mx = (int)lparam;
      int my = (int)dparam;
      bool mouseDown = ((int)sparam & 1) != 0;   // bit 0 = left button

      if(mouseDown && !g_dragging)
      {
         //---- Check if click is inside the title bar
         if(mx >= g_panelX && mx <= g_panelX + PANEL_W &&
            my >= g_panelY && my <= g_panelY + TITLE_H)
         {
            g_dragging = true;
            g_dragOffX = mx - g_panelX;
            g_dragOffY = my - g_panelY;
            ChartSetInteger(0, CHART_MOUSE_SCROLL, false);
         }
      }

      if(g_dragging)
      {
         if(mouseDown)
         {
            g_panelX = mx - g_dragOffX;
            g_panelY = my - g_dragOffY;
            MovePanel();
            ChartRedraw(0);
         }
         else
         {
            g_dragging = false;
            ChartSetInteger(0, CHART_MOUSE_SCROLL, true);
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Build all panel objects                                           |
//+------------------------------------------------------------------+
void BuildPanel()
{
   DeletePanel();

   int x  = g_panelX;
   int y  = g_panelY;

   //---- Background rectangle
   CreateLabel(OBJ_BG, x, y, PANEL_W, PANEL_H, clrDimGray, "");
   ObjectSetInteger(0, OBJ_BG, OBJPROP_BGCOLOR,   clrDimGray);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   // Use a rectangle label for the background
   ObjectDelete(0, OBJ_BG);
   ObjectCreate(0, OBJ_BG, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_CORNER,    CORNER_LEFT_UPPER);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_XSIZE,     PANEL_W);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_YSIZE,     PANEL_H);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_BGCOLOR,   clrDimGray);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_COLOR,     clrDimGray);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, OBJ_BG, OBJPROP_HIDDEN,    true);

   //---- Title bar (text label)
   CreateTextLabel(OBJ_TITLE, x + 6, y + 4, "Market Entry Panel",
                   clrWhite, 10, FW_BOLD);

   //---- Buttons (stacked vertically)
   int by = y + TITLE_H + GAP;
   CreateButton(OBJ_BTN_BUY,  x + BTN_X, by, BTN_W, BTN_H, "BUY",        clrForestGreen, clrWhite);
   by += BTN_H + GAP;
   CreateButton(OBJ_BTN_SELL, x + BTN_X, by, BTN_W, BTN_H, "SELL",       clrFireBrick,   clrWhite);
   by += BTN_H + GAP;
   CreateButton(OBJ_BTN_BE,   x + BTN_X, by, BTN_W, BTN_H, "Break Even", clrDarkOrange,  clrWhite);
   by += BTN_H + GAP;
   CreateButton(OBJ_BTN_CA,   x + BTN_X, by, BTN_W, BTN_H, "Close All",  clrSlateGray,   clrWhite);

   //---- Status label
   int sy = by + BTN_H + GAP;
   CreateTextLabel(OBJ_STATUS, x + 6, sy, "No open position", clrWhite, 9, FW_BOLD);
}

//+------------------------------------------------------------------+
void MovePanel()
{
   int x = g_panelX;
   int y = g_panelY;

   ObjectSetInteger(0, OBJ_BG,    OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, OBJ_BG,    OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, OBJ_TITLE, OBJPROP_XDISTANCE, x + 6);
   ObjectSetInteger(0, OBJ_TITLE, OBJPROP_YDISTANCE, y + 4);

   int by = y + TITLE_H + GAP;
   MoveObj(OBJ_BTN_BUY,  x + BTN_X, by); by += BTN_H + GAP;
   MoveObj(OBJ_BTN_SELL, x + BTN_X, by); by += BTN_H + GAP;
   MoveObj(OBJ_BTN_BE,   x + BTN_X, by); by += BTN_H + GAP;
   MoveObj(OBJ_BTN_CA,   x + BTN_X, by);

   int sy = by + BTN_H + GAP;
   ObjectSetInteger(0, OBJ_STATUS, OBJPROP_XDISTANCE, x + 6);
   ObjectSetInteger(0, OBJ_STATUS, OBJPROP_YDISTANCE, sy);
}

//+------------------------------------------------------------------+
void MoveObj(const string name, int x, int y)
{
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
}

//+------------------------------------------------------------------+
void DeletePanel()
{
   string names[] = { OBJ_BG, OBJ_TITLE, OBJ_BTN_BUY, OBJ_BTN_SELL,
                       OBJ_BTN_BE, OBJ_BTN_CA, OBJ_STATUS };
   for(int i = 0; i < ArraySize(names); i++)
      ObjectDelete(0, names[i]);
}

//+------------------------------------------------------------------+
void CreateButton(const string name, int x, int y, int w, int h,
                  const string text, color bg, color fg)
{
   ObjectCreate(0, name, OBJ_BUTTON, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_CORNER,    CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_XSIZE,     w);
   ObjectSetInteger(0, name, OBJPROP_YSIZE,     h);
   ObjectSetString (0, name, OBJPROP_TEXT,      text);
   ObjectSetInteger(0, name, OBJPROP_COLOR,     fg);
   ObjectSetInteger(0, name, OBJPROP_BGCOLOR,   bg);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE,  10);
   ObjectSetInteger(0, name, OBJPROP_FONT_ITALIC, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN,    true);
}

//+------------------------------------------------------------------+
void CreateTextLabel(const string name, int x, int y,
                     const string text, color clr,
                     int fontSize, int fontWeight)
{
   ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_CORNER,    CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetString (0, name, OBJPROP_TEXT,      text);
   ObjectSetInteger(0, name, OBJPROP_COLOR,     clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE,  fontSize);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN,    true);
}

//---- Unused helper kept for signature compatibility
void CreateLabel(const string name, int x, int y, int w, int h,
                 color clr, const string text) { }

//+------------------------------------------------------------------+
//| Enter a market order with ATR-based stop loss                    |
//+------------------------------------------------------------------+
void DoEntry(ENUM_ORDER_TYPE orderType)
{
   //---- Block if trade already open
   if(HasOpenPosition()) return;

   double atr = GetATR();
   if(atr <= 0) return;

   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   double ask   = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid   = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   int    digs  = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);

   double price, sl;

   if(orderType == ORDER_TYPE_BUY)
   {
      price = ask;
      sl    = NormalizeDouble(price - ATR_SL_Mult * atr, digs);
      g_trade.Buy(LotSize, _Symbol, price, sl, 0, "MEP Buy");
   }
   else
   {
      price = bid;
      sl    = NormalizeDouble(price + ATR_SL_Mult * atr, digs);
      g_trade.Sell(LotSize, _Symbol, price, sl, 0, "MEP Sell");
   }

   UpdateStatus();
}

//+------------------------------------------------------------------+
//| Move SL to entry price (break even)                              |
//+------------------------------------------------------------------+
void DoBreakEven()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      double entryPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      double currentSL  = PositionGetDouble(POSITION_SL);
      double currentTP  = PositionGetDouble(POSITION_TP);
      int    digs       = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
      double point      = SymbolInfoDouble(_Symbol, SYMBOL_POINT);

      ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double currentPrice = (posType == POSITION_TYPE_BUY)
                            ? SymbolInfoDouble(_Symbol, SYMBOL_BID)
                            : SymbolInfoDouble(_Symbol, SYMBOL_ASK);

      double profitPoints = (posType == POSITION_TYPE_BUY)
                            ? (currentPrice - entryPrice) / point
                            : (entryPrice - currentPrice) / point;

      if(profitPoints < BreakEvenPoints) continue;

      double newSL = NormalizeDouble(entryPrice, digs);
      if(posType == POSITION_TYPE_BUY  && newSL <= currentSL) continue;
      if(posType == POSITION_TYPE_SELL && newSL >= currentSL && currentSL > 0) continue;

      g_trade.PositionModify(ticket, newSL, currentTP);
   }
   UpdateStatus();
}

//+------------------------------------------------------------------+
//| Close all positions on this symbol managed by this EA            |
//+------------------------------------------------------------------+
void DoCloseAll()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      g_trade.PositionClose(ticket);
   }
   UpdateStatus();
}

//+------------------------------------------------------------------+
//| ATR trailing stop — only moves in the direction of the trade     |
//+------------------------------------------------------------------+
void TrailStop()
{
   double atr = GetATR();
   if(atr <= 0) return;

   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   int    digs  = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double currentSL = PositionGetDouble(POSITION_SL);
      double currentTP = PositionGetDouble(POSITION_TP);
      double trailDist = ATR_Trail_Mult * atr;
      double newSL;

      if(posType == POSITION_TYPE_BUY)
      {
         double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
         newSL = NormalizeDouble(bid - trailDist, digs);
         if(newSL > currentSL)
            g_trade.PositionModify(ticket, newSL, currentTP);
      }
      else
      {
         double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
         newSL = NormalizeDouble(ask + trailDist, digs);
         if(currentSL <= 0 || newSL < currentSL)
            g_trade.PositionModify(ticket, newSL, currentTP);
      }
   }
}

//+------------------------------------------------------------------+
//| Update the status label                                           |
//+------------------------------------------------------------------+
void UpdateStatus()
{
   string statusText = "No open position";

   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double lots     = PositionGetDouble(POSITION_VOLUME);
      double entry    = PositionGetDouble(POSITION_PRICE_OPEN);
      double profit   = PositionGetDouble(POSITION_PROFIT);
      double point    = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
      int    digs     = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
      double pipSize  = (digs == 3 || digs == 5) ? point * 10 : point;

      double currentPrice = (posType == POSITION_TYPE_BUY)
                            ? SymbolInfoDouble(_Symbol, SYMBOL_BID)
                            : SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double ptsRaw = (posType == POSITION_TYPE_BUY)
                      ? (currentPrice - entry)
                      : (entry - currentPrice);
      double pts  = ptsRaw / point;
      double pips = ptsRaw / pipSize;

      string dir   = (posType == POSITION_TYPE_BUY) ? "▲ Buy" : "▼ Sell";
      string sign  = (pts >= 0) ? "+" : "";
      statusText   = dir + " " + DoubleToString(lots, 2) +
                     " @ " + DoubleToString(entry, digs) +
                     " | " + sign + DoubleToString(pts,  1) + " pts" +
                     " / " + sign + DoubleToString(pips, 1) + " pips";
      break;
   }

   ObjectSetString(0, OBJ_STATUS, OBJPROP_TEXT, statusText);
   ChartRedraw(0);
}

//+------------------------------------------------------------------+
//| Return current ATR value (bar 1 = last confirmed bar)            |
//+------------------------------------------------------------------+
double GetATR()
{
   double buf[1];
   if(CopyBuffer(g_atrHandle, 0, 1, 1, buf) <= 0) return 0;
   return buf[0];
}

//+------------------------------------------------------------------+
//| Check whether this EA has an open position on this symbol        |
//+------------------------------------------------------------------+
bool HasOpenPosition()
{
   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) == MagicNumber) return true;
   }
   return false;
}
//+------------------------------------------------------------------+
