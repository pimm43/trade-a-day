//+------------------------------------------------------------------+
//|  KeltnerChannel_ColouredCandles.mq5                              |
//|  Keltner Channel with coloured candles:                          |
//|    Close ABOVE upper band  → LimeGreen candle                    |
//|    Close BELOW lower band  → Red candle                          |
//|    Close INSIDE bands      → Gray candle                         |
//|  Draws three KC lines (upper, middle, lower) on the price chart  |
//+------------------------------------------------------------------+
#property copyright "Trade-a-Day"
#property version   "1.00"
#property indicator_chart_window
#property indicator_buffers 8
#property indicator_plots   4

//---- Plot 0: Upper KC line
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrDodgerBlue
#property indicator_width1  1
#property indicator_label1  "KC Upper"

//---- Plot 1: Middle KC line (EMA)
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrGold
#property indicator_width2  1
#property indicator_label2  "KC Middle"

//---- Plot 2: Lower KC line
#property indicator_type3   DRAW_LINE
#property indicator_color3  clrDodgerBlue
#property indicator_width3  1
#property indicator_label3  "KC Lower"

//---- Plot 3: Coloured candles
#property indicator_type4   DRAW_COLOR_CANDLES
#property indicator_color4  clrLimeGreen, clrRed, clrGray
#property indicator_width4  1
#property indicator_label4  "Candle Open;Candle High;Candle Low;Candle Close"

//---- Inputs
input int    EMA_Period      = 20;              // EMA period (middle line)
input int    ATR_Period      = 20;              // ATR period
input double ATR_Multiplier  = 1.0;            // ATR multiplier
input color  UpperBandColor  = clrDodgerBlue;  // Upper band colour
input color  MiddleLineColor = clrGold;         // Middle line colour
input color  LowerBandColor  = clrDodgerBlue;  // Lower band colour
input int    BandLineWidth   = 1;              // Band line width
input color  ColorAbove      = clrLimeGreen;   // Candle: close above upper band
input color  ColorBelow      = clrRed;         // Candle: close below lower band
input color  ColorInside     = clrGray;        // Candle: close inside bands

//---- Buffers: KC lines (plots 0-2)
double UpperBuffer[];
double MiddleBuffer[];
double LowerBuffer[];

//---- Buffers: Coloured candles (plot 3) — open, high, low, close + colour index
double CandleOpen[];
double CandleHigh[];
double CandleLow[];
double CandleClose[];
double CandleColor[];   // 0=Above(LimeGreen), 1=Below(Red), 2=Inside(Gray)

//---- Indicator handles
int g_emaHandle = INVALID_HANDLE;
int g_atrHandle = INVALID_HANDLE;

//+------------------------------------------------------------------+
int OnInit()
{
   //---- Map buffers
   SetIndexBuffer(0, UpperBuffer,  INDICATOR_DATA);
   SetIndexBuffer(1, MiddleBuffer, INDICATOR_DATA);
   SetIndexBuffer(2, LowerBuffer,  INDICATOR_DATA);
   SetIndexBuffer(3, CandleOpen,   INDICATOR_DATA);
   SetIndexBuffer(4, CandleHigh,   INDICATOR_DATA);
   SetIndexBuffer(5, CandleLow,    INDICATOR_DATA);
   SetIndexBuffer(6, CandleClose,  INDICATOR_DATA);
   SetIndexBuffer(7, CandleColor,  INDICATOR_COLOR_INDEX);

   //---- Apply input colours / widths to plots
   PlotIndexSetInteger(0, PLOT_LINE_COLOR, UpperBandColor);
   PlotIndexSetInteger(0, PLOT_LINE_WIDTH, BandLineWidth);
   PlotIndexSetInteger(1, PLOT_LINE_COLOR, MiddleLineColor);
   PlotIndexSetInteger(1, PLOT_LINE_WIDTH, BandLineWidth);
   PlotIndexSetInteger(2, PLOT_LINE_COLOR, LowerBandColor);
   PlotIndexSetInteger(2, PLOT_LINE_WIDTH, BandLineWidth);

   //---- Apply candle colours (index 0/1/2 map to the three color4 values)
   PlotIndexSetInteger(3, PLOT_LINE_COLOR, 0, ColorAbove);
   PlotIndexSetInteger(3, PLOT_LINE_COLOR, 1, ColorBelow);
   PlotIndexSetInteger(3, PLOT_LINE_COLOR, 2, ColorInside);

   //---- Empty values
   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(2, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(3, PLOT_EMPTY_VALUE, EMPTY_VALUE);

   //---- Create handles
   g_emaHandle = iEMA(_Symbol, PERIOD_CURRENT, EMA_Period, 0, PRICE_CLOSE);
   g_atrHandle = iATR(_Symbol, PERIOD_CURRENT, ATR_Period);

   if(g_emaHandle == INVALID_HANDLE || g_atrHandle == INVALID_HANDLE)
   {
      Print("KC_ColouredCandles: Failed to create indicator handles.");
      return(INIT_FAILED);
   }

   IndicatorSetString(INDICATOR_SHORTNAME,
      "KC Coloured Candles (" + IntegerToString(EMA_Period) +
      "," + IntegerToString(ATR_Period) +
      "," + DoubleToString(ATR_Multiplier, 1) + ")");

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   if(g_emaHandle != INVALID_HANDLE) IndicatorRelease(g_emaHandle);
   if(g_atrHandle != INVALID_HANDLE) IndicatorRelease(g_atrHandle);
}

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double   &open[],
                const double   &high[],
                const double   &low[],
                const double   &close[],
                const long     &tick_volume[],
                const long     &volume[],
                const int      &spread[])
{
   int minBars = MathMax(EMA_Period, ATR_Period) + 1;
   if(rates_total < minBars) return 0;

   //---- Copy EMA and ATR into local chronological arrays
   double emaLocal[];
   double atrLocal[];
   ArraySetAsSeries(emaLocal, false);
   ArraySetAsSeries(atrLocal, false);
   ArrayResize(emaLocal, rates_total);
   ArrayResize(atrLocal, rates_total);

   if(CopyBuffer(g_emaHandle, 0, 0, rates_total, emaLocal) <= 0) return 0;
   if(CopyBuffer(g_atrHandle, 0, 0, rates_total, atrLocal) <= 0) return 0;

   //---- Copy OHLC into local chronological arrays
   double o[], h[], l[], c[];
   ArraySetAsSeries(o, false);
   ArraySetAsSeries(h, false);
   ArraySetAsSeries(l, false);
   ArraySetAsSeries(c, false);
   ArrayResize(o, rates_total);
   ArrayResize(h, rates_total);
   ArrayResize(l, rates_total);
   ArrayResize(c, rates_total);
   CopyOpen (_Symbol, PERIOD_CURRENT, 0, rates_total, o);
   CopyHigh (_Symbol, PERIOD_CURRENT, 0, rates_total, h);
   CopyLow  (_Symbol, PERIOD_CURRENT, 0, rates_total, l);
   CopyClose(_Symbol, PERIOD_CURRENT, 0, rates_total, c);

   int start = (prev_calculated <= 1) ? minBars : prev_calculated - 1;

   for(int i = start; i < rates_total; i++)
   {
      double ema   = emaLocal[i];
      double atr   = atrLocal[i];
      double upper = ema + ATR_Multiplier * atr;
      double lower = ema - ATR_Multiplier * atr;

      //---- KC lines
      UpperBuffer[i]  = upper;
      MiddleBuffer[i] = ema;
      LowerBuffer[i]  = lower;

      //---- Coloured candles
      CandleOpen[i]  = o[i];
      CandleHigh[i]  = h[i];
      CandleLow[i]   = l[i];
      CandleClose[i] = c[i];

      if(c[i] > upper)
         CandleColor[i] = 0;   // ColorAbove (LimeGreen)
      else if(c[i] < lower)
         CandleColor[i] = 1;   // ColorBelow (Red)
      else
         CandleColor[i] = 2;   // ColorInside (Gray)
   }

   return(rates_total);
}
//+------------------------------------------------------------------+
