//+------------------------------------------------------------------+
//|  WPR_Momentum_Strict.mq5                                         |
//|  Momentum interpretation with strict Buy→Sell alternation:       |
//|    BUY  – WPR crosses and closes ABOVE −20 (first entry only)   |
//|    SELL – WPR crosses and closes BELOW −80 (first entry only)   |
//|  Once a Buy fires, no further Buys until a Sell fires, and       |
//|  vice versa.                                                      |
//+------------------------------------------------------------------+
#property copyright "Trade-a-Day"
#property version   "1.00"
#property indicator_plots   3
#property indicator_buffers 3

//---- Subwindow
#property indicator_separate_window
#property indicator_minimum -100
#property indicator_maximum 0

//---- WPR line (plot 0)
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrDodgerBlue
#property indicator_width1  1
#property indicator_label1  "WPR"

//---- Buy arrows (plot 1)
#property indicator_type2   DRAW_ARROW
#property indicator_color2  clrLimeGreen
#property indicator_width2  2
#property indicator_label2  "Buy"

//---- Sell arrows (plot 2)
#property indicator_type3   DRAW_ARROW
#property indicator_color3  clrCrimson
#property indicator_width3  2
#property indicator_label3  "Sell"

//---- Inputs
input int    WPR_Period      = 14;
input double BuyLevel        = -20.0;   // WPR level for Buy signal
input double SellLevel       = -80.0;   // WPR level for Sell signal
input int    BuyArrowCode    = 233;
input int    SellArrowCode   = 234;
input double ArrowDistance   = 2.0;     // Offset from WPR value (WPR units)
input color  BuyArrowColor   = clrLimeGreen;
input color  SellArrowColor  = clrCrimson;
input int    ArrowSize       = 2;
input bool   SoundAlert      = true;
input string BuySoundFile    = "alert.wav";
input string SellSoundFile   = "alert2.wav";
input bool   PopupAlert      = false;
input bool   ShowOnChart     = false;   // Mirror arrows on price chart

//---- Buffers
double WPRBuffer[];
double BuyBuffer[];
double SellBuffer[];

//---- State
string ObjPrefix   = "WPRMX_";
datetime g_lastAlertBar = 0;

//+------------------------------------------------------------------+
int OnInit()
{
   SetIndexBuffer(0, WPRBuffer, INDICATOR_DATA);
   SetIndexBuffer(1, BuyBuffer,  INDICATOR_DATA);
   SetIndexBuffer(2, SellBuffer, INDICATOR_DATA);

   PlotIndexSetInteger(1, PLOT_ARROW, BuyArrowCode);
   PlotIndexSetInteger(2, PLOT_ARROW, SellArrowCode);
   PlotIndexSetInteger(1, PLOT_LINE_COLOR, 0, BuyArrowColor);
   PlotIndexSetInteger(2, PLOT_LINE_COLOR, 0, SellArrowColor);
   PlotIndexSetInteger(1, PLOT_LINE_WIDTH, ArrowSize);
   PlotIndexSetInteger(2, PLOT_LINE_WIDTH, ArrowSize);

   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(2, PLOT_EMPTY_VALUE, EMPTY_VALUE);

   // Reference lines
   double levels[3] = {-20.0, -50.0, -80.0};
   for(int i = 0; i < 3; i++)
   {
      string nm = ObjPrefix + "Lvl" + IntegerToString((int)MathAbs(levels[i]));
      if(ObjectFind(0, nm) < 0)
         ObjectCreate(0, nm, OBJ_HLINE, ChartWindowFind(), 0, levels[i]);
      ObjectSetInteger(0, nm, OBJPROP_COLOR, clrSilver);
      ObjectSetInteger(0, nm, OBJPROP_STYLE, STYLE_DOT);
      ObjectSetInteger(0, nm, OBJPROP_WIDTH, 1);
      ObjectSetString( 0, nm, OBJPROP_TOOLTIP, DoubleToString(levels[i], 0));
   }

   IndicatorSetString(INDICATOR_SHORTNAME,
      "WPR Momentum Strict(" + IntegerToString(WPR_Period) + ")");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   double levels[3] = {-20.0, -50.0, -80.0};
   for(int i = 0; i < 3; i++)
   {
      string nm = ObjPrefix + "Lvl" + IntegerToString((int)MathAbs(levels[i]));
      ObjectDelete(0, nm);
   }
   if(ShowOnChart)
   {
      int total = ObjectsTotal(0, 0, -1);
      for(int i = total - 1; i >= 0; i--)
      {
         string oname = ObjectName(0, i, 0, -1);
         if(StringFind(oname, ObjPrefix + "PC_") == 0)
            ObjectDelete(0, oname);
      }
   }
}

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double   &open[],
                const double   &high[],
                const double   &low[],
                const double   &close[],
                const long     &tick_volume[],
                const long     &volume[],
                const int      &spread[])
{
   if(rates_total < WPR_Period + 1) return 0;

   // Copy WPR (chronological: index 0 = oldest)
   double wprLocal[];
   ArraySetAsSeries(wprLocal, false);
   ArrayResize(wprLocal, rates_total);

   int handle = iWPR(_Symbol, PERIOD_CURRENT, WPR_Period);
   if(handle == INVALID_HANDLE) return 0;
   if(CopyBuffer(handle, 0, 0, rates_total, wprLocal) <= 0) return 0;
   IndicatorRelease(handle);

   // Always recalculate from the start so the alternation state is correct
   int start = WPR_Period;

   // Replay history to establish correct last-signal state up to prev_calculated
   // then continue from there for new bars.
   int lastSig = 0;  // 0=none, 1=buy, -1=sell

   // First pass: replay all confirmed bars to get lastSig right
   int replayEnd = (prev_calculated > 1) ? prev_calculated - 1 : rates_total;

   for(int i = start; i < replayEnd; i++)
   {
      WPRBuffer[i] = wprLocal[i];
      BuyBuffer[i]  = EMPTY_VALUE;
      SellBuffer[i] = EMPTY_VALUE;

      double wpr  = wprLocal[i];
      double wprP = wprLocal[i - 1];

      bool rawBuy  = (wprP <= BuyLevel  && wpr > BuyLevel);
      bool rawSell = (wprP >= SellLevel && wpr < SellLevel);

      if(rawBuy && lastSig != 1)
      {
         BuyBuffer[i] = wpr - ArrowDistance;
         lastSig = 1;
         if(ShowOnChart) DrawChartArrow(true, time[i], low[i], i);
      }
      else if(rawSell && lastSig != -1)
      {
         SellBuffer[i] = wpr + ArrowDistance;
         lastSig = -1;
         if(ShowOnChart) DrawChartArrow(false, time[i], high[i], i);
      }
   }

   // Second pass: live bars (from prev_calculated-1 onward)
   int liveStart = (prev_calculated > 1) ? prev_calculated - 1 : replayEnd;
   for(int i = liveStart; i < rates_total; i++)
   {
      WPRBuffer[i] = wprLocal[i];
      BuyBuffer[i]  = EMPTY_VALUE;
      SellBuffer[i] = EMPTY_VALUE;

      double wpr  = wprLocal[i];
      double wprP = wprLocal[i - 1];

      bool rawBuy  = (wprP <= BuyLevel  && wpr > BuyLevel);
      bool rawSell = (wprP >= SellLevel && wpr < SellLevel);

      if(rawBuy && lastSig != 1)
      {
         BuyBuffer[i] = wpr - ArrowDistance;
         lastSig = 1;
         if(ShowOnChart) DrawChartArrow(true, time[i], low[i], i);

         if(i == rates_total - 1 && time[i] != g_lastAlertBar)
         {
            g_lastAlertBar = time[i];
            if(SoundAlert) PlaySound(BuySoundFile);
            if(PopupAlert) Alert("WPR Momentum BUY — ", _Symbol,
                                 " WPR=", DoubleToString(wpr, 2));
         }
      }
      else if(rawSell && lastSig != -1)
      {
         SellBuffer[i] = wpr + ArrowDistance;
         lastSig = -1;
         if(ShowOnChart) DrawChartArrow(false, time[i], high[i], i);

         if(i == rates_total - 1 && time[i] != g_lastAlertBar)
         {
            g_lastAlertBar = time[i];
            if(SoundAlert) PlaySound(SellSoundFile);
            if(PopupAlert) Alert("WPR Momentum SELL — ", _Symbol,
                                 " WPR=", DoubleToString(wpr, 2));
         }
      }
   }

   return(rates_total);
}

//+------------------------------------------------------------------+
void DrawChartArrow(bool buy, datetime t, double price, int idx)
{
   string nm = ObjPrefix + "PC_" + IntegerToString(idx);
   if(ObjectFind(0, nm) >= 0) ObjectDelete(0, nm);
   ObjectCreate(0, nm, OBJ_ARROW, 0, t, price);
   ObjectSetInteger(0, nm, OBJPROP_ARROWCODE,
                    buy ? BuyArrowCode : SellArrowCode);
   ObjectSetInteger(0, nm, OBJPROP_COLOR,
                    buy ? BuyArrowColor : SellArrowColor);
   ObjectSetInteger(0, nm, OBJPROP_WIDTH, ArrowSize);
   ObjectSetInteger(0, nm, OBJPROP_ANCHOR,
                    buy ? ANCHOR_TOP : ANCHOR_BOTTOM);
}
//+------------------------------------------------------------------+
