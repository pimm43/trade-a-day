//+------------------------------------------------------------------+
//|  SwingTrendLines.mq5                                             |
//|  Automatically draws two live trendlines on the price chart:     |
//|    Upper line — through the two most recent confirmed swing highs |
//|    Lower line — through the two most recent confirmed swing lows  |
//|  Both lines extend to the right as rays and update each bar.     |
//+------------------------------------------------------------------+
#property copyright "Trade-a-Day"
#property version   "1.00"
#property indicator_chart_window
#property indicator_buffers 0
#property indicator_plots   0

//---- Object names
#define OBJ_UPPER  "STL_Upper"
#define OBJ_LOWER  "STL_Lower"

//---- Inputs
input int    LookbackBars   = 8;              // Bars either side to confirm a swing
input color  UpperLineColor = clrCrimson;     // Upper trendline colour
input color  LowerLineColor = clrDodgerBlue;  // Lower trendline colour
input int    LineWidth       = 2;             // Line width
input ENUM_LINE_STYLE LineStyle = STYLE_SOLID; // Line style

//+------------------------------------------------------------------+
int OnInit()
{
   IndicatorSetString(INDICATOR_SHORTNAME,
      "Swing Trend Lines (" + IntegerToString(LookbackBars) + ")");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   ObjectDelete(0, OBJ_UPPER);
   ObjectDelete(0, OBJ_LOWER);
}

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double   &open[],
                const double   &high[],
                const double   &low[],
                const double   &close[],
                const long     &tick_volume[],
                const long     &volume[],
                const int      &spread[])
{
   // Need enough bars to test LookbackBars either side of each candidate
   int minBars = LookbackBars * 2 + 2;
   if(rates_total < minBars) return 0;

   //---- Copy high / low into chronological arrays (index 0 = oldest)
   double hiArr[];
   double loArr[];
   datetime tmArr[];
   ArraySetAsSeries(hiArr,  false);
   ArraySetAsSeries(loArr,  false);
   ArraySetAsSeries(tmArr,  false);
   ArrayResize(hiArr,  rates_total);
   ArrayResize(loArr,  rates_total);
   ArrayResize(tmArr,  rates_total);

   if(CopyHigh(_Symbol, PERIOD_CURRENT, 0, rates_total, hiArr) <= 0) return 0;
   if(CopyLow (_Symbol, PERIOD_CURRENT, 0, rates_total, loArr) <= 0) return 0;
   if(CopyTime(_Symbol, PERIOD_CURRENT, 0, rates_total, tmArr) <= 0) return 0;

   // Confirmed bars only: exclude the last (live) bar
   int lastConfirmed = rates_total - 2;

   //---- Collect the two most recent swing highs and swing lows
   int   swHiIdx[2];  double swHiVal[2];  // [0]=most recent, [1]=previous
   int   swLoIdx[2];  double swLoVal[2];
   int   hiCount = 0, loCount = 0;

   for(int i = lastConfirmed; i >= LookbackBars && (hiCount < 2 || loCount < 2); i--)
   {
      //---- Swing high check
      if(hiCount < 2)
      {
         bool isHigh = true;
         for(int k = 1; k <= LookbackBars; k++)
         {
            if(hiArr[i - k] >= hiArr[i] || hiArr[i + k] >= hiArr[i])
            {
               isHigh = false;
               break;
            }
         }
         if(isHigh)
         {
            swHiIdx[hiCount] = i;
            swHiVal[hiCount] = hiArr[i];
            hiCount++;
         }
      }

      //---- Swing low check
      if(loCount < 2)
      {
         bool isLow = true;
         for(int k = 1; k <= LookbackBars; k++)
         {
            if(loArr[i - k] <= loArr[i] || loArr[i + k] <= loArr[i])
            {
               isLow = false;
               break;
            }
         }
         if(isLow)
         {
            swLoIdx[loCount] = i;
            swLoVal[loCount] = loArr[i];
            loCount++;
         }
      }
   }

   //---- Draw / update upper trendline
   if(hiCount >= 2)
   {
      // swHiIdx[1] is the older point, swHiIdx[0] is the more recent
      datetime t1 = tmArr[swHiIdx[1]];
      double   p1 = swHiVal[swHiIdx[1]];
      datetime t2 = tmArr[swHiIdx[0]];
      double   p2 = swHiVal[swHiIdx[0]];
      DrawTrendLine(OBJ_UPPER, t1, p1, t2, p2, UpperLineColor);
   }
   else
   {
      ObjectDelete(0, OBJ_UPPER);
   }

   //---- Draw / update lower trendline
   if(loCount >= 2)
   {
      datetime t1 = tmArr[swLoIdx[1]];
      double   p1 = swLoVal[swLoIdx[1]];
      datetime t2 = tmArr[swLoIdx[0]];
      double   p2 = swLoVal[swLoIdx[0]];
      DrawTrendLine(OBJ_LOWER, t1, p1, t2, p2, LowerLineColor);
   }
   else
   {
      ObjectDelete(0, OBJ_LOWER);
   }

   return(rates_total);
}

//+------------------------------------------------------------------+
void DrawTrendLine(const string name,
                   datetime t1, double p1,
                   datetime t2, double p2,
                   color    lineColor)
{
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TREND, 0, t1, p1, t2, p2);
   else
   {
      ObjectSetInteger(0, name, OBJPROP_TIME,  0, t1);
      ObjectSetDouble (0, name, OBJPROP_PRICE, 0, p1);
      ObjectSetInteger(0, name, OBJPROP_TIME,  1, t2);
      ObjectSetDouble (0, name, OBJPROP_PRICE, 1, p2);
   }
   ObjectSetInteger(0, name, OBJPROP_COLOR,    lineColor);
   ObjectSetInteger(0, name, OBJPROP_WIDTH,    LineWidth);
   ObjectSetInteger(0, name, OBJPROP_STYLE,    LineStyle);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN,   true);
}
//+------------------------------------------------------------------+
