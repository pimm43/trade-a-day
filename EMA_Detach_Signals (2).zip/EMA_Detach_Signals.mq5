//+------------------------------------------------------------------+
//|                                      EMA_Detach_Signals.mq5     |
//|                                                                  |
//|  Fires an arrow on the FIRST candle to be completely detached   |
//|  from the EMA (shifted 1 bar to the right).                     |
//|                                                                  |
//|  BUY  arrow: candle closes ABOVE the shifted EMA                |
//|              AND the candle LOW is ABOVE the shifted EMA        |
//|              (no part of the candle touches or is below the EMA)|
//|              AND the previous bar was NOT fully above           |
//|              (i.e. this is the first detachment)                |
//|              AND the last signal was a Sell (strict alternation)|
//|                                                                  |
//|  SELL arrow: candle closes BELOW the shifted EMA                |
//|              AND the candle HIGH is BELOW the shifted EMA       |
//|              (no part of the candle touches or is above the EMA)|
//|              AND the previous bar was NOT fully below           |
//|              AND the last signal was a Buy (strict alternation) |
//|                                                                  |
//|  Sequence is strictly: Buy, Sell, Buy, Sell …                  |
//|  Default: 8-period EMA, shift 1, applied to Close.             |
//|  The EMA line is also drawn for reference.                      |
//+------------------------------------------------------------------+
#property copyright   "Trade-a-Day"
#property version     "1.01"
#property indicator_chart_window
#property indicator_buffers 3
#property indicator_plots   3

//--- EMA line
#property indicator_label1  "EMA"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrGold
#property indicator_width1  1

//--- BUY arrow
#property indicator_label2  "EMA Detach Buy"
#property indicator_type2   DRAW_ARROW
#property indicator_color2  clrLimeGreen
#property indicator_width2  2

//--- SELL arrow
#property indicator_label3  "EMA Detach Sell"
#property indicator_type3   DRAW_ARROW
#property indicator_color3  clrCrimson
#property indicator_width3  2

//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
input group "=== EMA Settings ==="
input int              EMA_Period  = 8;           // EMA Period
input int              EMA_Shift   = 1;           // EMA Shift (bars to the right)
input ENUM_APPLIED_PRICE EMA_Price = PRICE_CLOSE; // EMA Applied Price
input color            EMAColor    = clrGold;     // EMA line colour

input group "=== Arrow Appearance ==="
input color  BuyColor      = clrLimeGreen;  // Buy arrow colour
input color  SellColor     = clrCrimson;    // Sell arrow colour
input int    ArrowSize     = 2;             // Arrow size (1–5)
input int    BuyArrowCode  = 233;           // Buy arrow code
input int    SellArrowCode = 234;           // Sell arrow code
input int    ArrowDistance = 4;             // Distance from candle (points)

input group "=== Alerts ==="
input bool   AlertOnNew    = false;         // Alert on new signal

//+------------------------------------------------------------------+
//| Buffers                                                          |
//+------------------------------------------------------------------+
double g_ema[];
double g_buyBuffer[];
double g_sellBuffer[];

//+------------------------------------------------------------------+
//| Handle and alert tracking                                        |
//+------------------------------------------------------------------+
int      g_maHandle      = INVALID_HANDLE;
datetime g_lastAlertBar  = 0;

//+------------------------------------------------------------------+
//| OnInit                                                           |
//+------------------------------------------------------------------+
int OnInit()
{
   SetIndexBuffer(0, g_ema,        INDICATOR_DATA);
   SetIndexBuffer(1, g_buyBuffer,  INDICATOR_DATA);
   SetIndexBuffer(2, g_sellBuffer, INDICATOR_DATA);

   //--- EMA line
   PlotIndexSetInteger(0, PLOT_LINE_COLOR,  EMAColor);
   PlotIndexSetDouble (0, PLOT_EMPTY_VALUE, EMPTY_VALUE);

   //--- BUY arrow
   PlotIndexSetInteger(1, PLOT_ARROW,       BuyArrowCode);
   PlotIndexSetInteger(1, PLOT_LINE_COLOR,  BuyColor);
   PlotIndexSetInteger(1, PLOT_LINE_WIDTH,  ArrowSize);
   PlotIndexSetDouble (1, PLOT_EMPTY_VALUE, EMPTY_VALUE);

   //--- SELL arrow
   PlotIndexSetInteger(2, PLOT_ARROW,       SellArrowCode);
   PlotIndexSetInteger(2, PLOT_LINE_COLOR,  SellColor);
   PlotIndexSetInteger(2, PLOT_LINE_WIDTH,  ArrowSize);
   PlotIndexSetDouble (2, PLOT_EMPTY_VALUE, EMPTY_VALUE);

   //--- EMA handle with shift applied
   g_maHandle = iMA(_Symbol, _Period, EMA_Period, EMA_Shift, MODE_EMA, EMA_Price);
   if(g_maHandle == INVALID_HANDLE)
   {
      Alert("EMA Detach: Failed to create MA handle.");
      return INIT_FAILED;
   }

   IndicatorSetString(INDICATOR_SHORTNAME,
      StringFormat("EMA Detach Strict(%d s%d)", EMA_Period, EMA_Shift));
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| OnDeinit                                                         |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   if(g_maHandle != INVALID_HANDLE) IndicatorRelease(g_maHandle);
}

//+------------------------------------------------------------------+
//| OnCalculate                                                      |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double   &open[],
                const double   &high[],
                const double   &low[],
                const double   &close[],
                const long     &tick_volume[],
                const long     &volume[],
                const int      &spread[])
{
   if(rates_total < EMA_Period + EMA_Shift + 2) return 0;

   //--- Copy EMA buffer in chronological order (index 0 = oldest)
   ArraySetAsSeries(time,  false);
   ArraySetAsSeries(high,  false);
   ArraySetAsSeries(low,   false);
   ArraySetAsSeries(close, false);

   if(CopyBuffer(g_maHandle, 0, 0, rates_total, g_ema) <= 0) return 0;

   double arrowDist = ArrowDistance * SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   int    firstBar  = EMA_Period + EMA_Shift + 1;

   if(prev_calculated <= 1)
   {
      ArrayInitialize(g_buyBuffer,  EMPTY_VALUE);
      ArrayInitialize(g_sellBuffer, EMPTY_VALUE);
   }

   //==================================================================
   // Always replay full history so lastSig is correct for alternation
   //==================================================================
   int lastSig = 0;  // 0=none, 1=buy was last, -1=sell was last

   //---- Pass 1: replay confirmed history to establish lastSig
   int replayEnd = (prev_calculated > 1) ? prev_calculated - 1 : rates_total;

   for(int i = firstBar; i < replayEnd; i++)
   {
      g_buyBuffer [i] = EMPTY_VALUE;
      g_sellBuffer[i] = EMPTY_VALUE;

      if(g_ema[i] <= 0 || g_ema[i - 1] <= 0) continue;

      bool aboveNow  = (close[i]     > g_ema[i]     && low[i]      > g_ema[i]);
      bool abovePrev = (close[i - 1] > g_ema[i - 1] && low[i - 1]  > g_ema[i - 1]);
      bool belowNow  = (close[i]     < g_ema[i]     && high[i]     < g_ema[i]);
      bool belowPrev = (close[i - 1] < g_ema[i - 1] && high[i - 1] < g_ema[i - 1]);

      if(aboveNow && !abovePrev && lastSig != 1)
      {
         g_buyBuffer[i] = low[i] - arrowDist;
         lastSig = 1;
      }
      else if(belowNow && !belowPrev && lastSig != -1)
      {
         g_sellBuffer[i] = high[i] + arrowDist;
         lastSig = -1;
      }
   }

   //---- Pass 2: live bars — signal + optional alert
   int liveStart = (prev_calculated > 1) ? prev_calculated - 1 : replayEnd;

   for(int i = liveStart; i < rates_total; i++)
   {
      g_buyBuffer [i] = EMPTY_VALUE;
      g_sellBuffer[i] = EMPTY_VALUE;

      if(g_ema[i] <= 0 || g_ema[i - 1] <= 0) continue;

      bool aboveNow  = (close[i]     > g_ema[i]     && low[i]      > g_ema[i]);
      bool abovePrev = (close[i - 1] > g_ema[i - 1] && low[i - 1]  > g_ema[i - 1]);
      bool belowNow  = (close[i]     < g_ema[i]     && high[i]     < g_ema[i]);
      bool belowPrev = (close[i - 1] < g_ema[i - 1] && high[i - 1] < g_ema[i - 1]);

      if(aboveNow && !abovePrev && lastSig != 1)
      {
         g_buyBuffer[i] = low[i] - arrowDist;
         lastSig = 1;

         if(AlertOnNew && i == rates_total - 1 && time[i] != g_lastAlertBar)
         {
            g_lastAlertBar = time[i];
            Alert(StringFormat(
               "%s  EMA Detach BUY — fully above EMA(%.5f)  low=%.5f  [%s]",
               _Symbol, g_ema[i], low[i],
               TimeToString(time[i], TIME_DATE | TIME_MINUTES)));
         }
      }
      else if(belowNow && !belowPrev && lastSig != -1)
      {
         g_sellBuffer[i] = high[i] + arrowDist;
         lastSig = -1;

         if(AlertOnNew && i == rates_total - 1 && time[i] != g_lastAlertBar)
         {
            g_lastAlertBar = time[i];
            Alert(StringFormat(
               "%s  EMA Detach SELL — fully below EMA(%.5f)  high=%.5f  [%s]",
               _Symbol, g_ema[i], high[i],
               TimeToString(time[i], TIME_DATE | TIME_MINUTES)));
         }
      }
   }

   return rates_total;
}
//+------------------------------------------------------------------+
